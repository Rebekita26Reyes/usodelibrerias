package natalia.flores.usodeimagenes;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import com.squareup.picasso.Picasso;

public class MainActivity extends AppCompatActivity {

    ImageView img01;
    Button btn1, btn2, btn3, btn4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        img01 = findViewById(R.id.img01);
        btn1 = findViewById(R.id.btn1);
        btn2 = findViewById(R.id.btn2);
        btn3 = findViewById(R.id.btn3);
        btn4 = findViewById(R.id.btn4);

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public  void onClick(View view) {
                Picasso.get().load(R.drawable.imagen1).into(img01);
            }
        });

        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public  void onClick(View view) {
                Picasso.get()
                        .load(R.drawable.imagen2)
                        .resize(512, 512)
                        .centerCrop()
                        .into(img01);

            }
        });

        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public  void onClick(View view) {
               Picasso.get()
                       .load(R.drawable.imagen3)
                       .into(img01);
            }
        });

        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public  void onClick(View view) {
                Picasso.get()
                        .load("https://developer.android.com/images/social/android-developers.png")
                        .into(img01);
            }
        });
    }

}